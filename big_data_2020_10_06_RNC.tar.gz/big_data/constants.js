const KEY_FEMALE = "Female";
const KEY_ADULT = "Adult";
const PREDICTOR_NAMES = [
    "Everyone (intercept)",

    KEY_ADULT,
    KEY_FEMALE,

    "Employed or at school",
    "Employs others",
    "Furloughed",
    "Parent",
    "Homework",
    "Housework",
    "Hobbies",
    "Won the lottery",
];

const PREDICTOR_PROBABILITIES = {
    // Probability that a member of the sample has this predictive attribute.

    "Everyone (intercept)": 1,
    "Adult": 0.761,  // approximately! This is based on 0.239 for 0-19y.
    // ... https://en.wikipedia.org/wiki/Demography_of_the_United_Kingdom#Age_structure
    "Female": 0.508,

    // These are all made up:
    "Employed or at school": 0.8,
    "Employs others": 0.05,
    "Furloughed": 0.1,
    "Parent": 0.4,
    "Homework": 0.7,
    "Housework": 0.4,
    "Hobbies": 0.5,
    "Won the lottery": 0.0001,
};

const PREDICTOR_DELTA_LOG_ODDS = {
    // Change in risk of being affected as a consequence of having each
    // predictor attribute.
    //
    // They're all made up. 0 means no effect; >0 means "more time on your
    // hands", <0 means "less time on your hands".

    "Everyone (intercept)": -0.2,

    "Adult": -1.0,
    "Female": 0.0,

    "Employed or at school": -2.0,
    "Employs others": +0.6,
    "Furloughed": +1.0,
    "Parent": -2.0,
    "Homework": -0.8,
    "Housework": -1.2,
    "Hobbies": -0.5,
    "Won the lottery": +2.5,
}

const SD_LOG_ERROR = 0.5;

const KEY_MEN = "Men";
const KEY_WOMEN = "Women";
const KEY_BOYS = "Boys";
const KEY_GIRLS = "Girls";
const AGE_GENDER_KEYS = [
    KEY_MEN,
    KEY_WOMEN,
    KEY_BOYS,
    KEY_GIRLS,
]

const KEY_ODDS_RATIO = "OR";
const KEY_CI_UPPER = "CI_upper";
const KEY_CI_LOWER = "CI_lower";

// HTML IDs
const HTML_ID_TEXTBOX = "input-participants";
const HTML_ID_SLIDER = "slider-participants";
const HTML_ID_GRAPH = "grid-output-graphical";
const HTML_ID_AGE_GENDER_TABLE = "gender_age_table";
const HTML_ID_RISK_FACTOR_TABLE = "risk_factor_table";
const URL_PARAM_N = "n";
