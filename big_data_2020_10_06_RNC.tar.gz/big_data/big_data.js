// big_data.js
// Illustration of logistic regression as the user varies n.

// ============================================================================
// Startup
// ============================================================================

// Called by the HTML.
function initialize() {
    fetchNThenBuild();
}


// ============================================================================
// User interface
// ============================================================================

function participantNumChangeText() {
    const n_str = document.getElementById(HTML_ID_TEXTBOX).value;
    const n = parseInt(n_str);
    reloadWithNewN(n);
}


function participantNumChangeSlider() {
    const n_str = document.getElementById(HTML_ID_SLIDER).value;
    const n = parseInt(n_str);
    reloadWithNewN(n);
}


function reloadWithNewN(n, debug = false) {
    const url = new URL(location.href);
    console.log("url:", url);
    const search = "?" + URL_PARAM_N + "=" + n.toString();
    const new_url = url.origin + url.pathname + search;
    // https://developer.mozilla.org/en-US/docs/Web/API/URL
    // - origin: scheme + domain + port
    // - pathname: the rest but not the query
    if (debug) {
        console.log("url:", url);
        console.log("new_url:", new_url);
        console.log("Reloading page...");
    }
    location.href = new_url;  // will reload
    // Don't call location.reload() as well.
}


function fetchNThenBuild(debug = false) {
    // https://stackoverflow.com/questions/979975/how-to-get-the-value-from-the-get-parameters
    // https://developer.mozilla.org/en-US/docs/Web/API/URL
    const url = new URL(location.href);
    const n_from_url = parseInt(url.searchParams.get(URL_PARAM_N));
    const n_from_slider =
        parseInt(document.getElementById(HTML_ID_SLIDER).value);
    let n = n_from_slider;
    if (debug) {
        console.log("url:", url);
        console.log("n_from_url:", n_from_url);
        console.log("n_from_slider:", n_from_slider);
    }
    if (!isNaN(n_from_url)) {
        // n validly specified from URL, e.g. "?n=5"
        n = n_from_url;
        if (n_from_url !== n_from_slider) {
            if (debug) {
                console.log("Setting slider/textbox from URL...");
            }
            const n_str = n_from_url.toString();
            document.getElementById(HTML_ID_SLIDER).value = n_str;
            document.getElementById(HTML_ID_TEXTBOX).value = n_str;
        }
    }
    // n = 100;  // for debugging
    buildModel(n);
}


// ============================================================================
// HTML and text formatting
// ============================================================================

function tag(tag, text) {
    // Applies an HMTL tag
    return "<" + tag + ">" + text + "</" + tag + ">";
}


function tr(columns, cell_tag = "td") {
    let lines = ["<tr>"];
    for (let i = 0; i < columns.length; ++i) {
        lines.push(tag(cell_tag, columns[i]))
    }
    lines.push("</tr>")
    return lines.join("\n")
}


function bold(text) {
    return tag("b", text);
}


function thead(text) {
    return tag("thead", text);
}


function tbody(text) {
    return tag("tbody", text);
}


function tfoot(text) {
    return tag("tfoot", text);
}


function n_percent(numerator, denominator) {
    const pct = Math.round(100 * numerator / denominator);
    if (isNaN(pct)) {
        return numerator.toString();
    }
    return numerator.toString() + " (" + pct.toString() + "%)";
}


// ============================================================================
// Statistical helper functions
// ============================================================================

function getRatio(num_a, num_b, denom_a, denom_b) {

    // Calculating the odds ratio and 95% confidence interval
    // https://www.medcalc.org/calc/odds_ratio.php
    // ^
    // +--- The calculation I believe I am doing is here under computational
    //      notes
    // ... yup: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1127651

    const oddsRatio = (num_a / denom_a) / (num_b / denom_b);
    const SElnOddsRatio = Math.sqrt(
        (1 / num_a) + (1 / denom_a) + (1 / num_b) + (1 / denom_b)
    );
    const lnOR = Math.log(oddsRatio);
    const ciPositive = Math.exp(lnOR + (1.96 * SElnOddsRatio));
    const ciNegative = Math.exp(lnOR - (1.96 * SElnOddsRatio));

    // Round to 2dp:
    const oddsRatio2dp = Math.round(oddsRatio * 100) / 100;
    const ciPositive2dp = Math.round(ciPositive * 100) / 100;
    const ciNegative2dp = Math.round(ciNegative * 100) / 100;

    let result = {};
    result[KEY_ODDS_RATIO] = oddsRatio2dp;
    result[KEY_CI_LOWER] = ciNegative2dp;
    result[KEY_CI_UPPER] = ciPositive2dp;
    return result;
}


function randStandardNormal() {
    // Standard normal variate using Box-Muller transform.
    // https://stackoverflow.com/questions/25582882/javascript-math-random-normal-distribution-gaussian-bell-curve
    let u = 0;
    let v = 0;
    while (u === 0) {
        u = Math.random();
    }  // Converting [0,1) to (0,1)
    while (v === 0) {
        v = Math.random();
    }
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}


function probabilityFromOdds(odds) {
    // The parameter is a math.js matrix/array object.
    // p = odds / (1 + odds)
    // noinspection JSUnresolvedFunction,JSUnresolvedVariable
    return math.dotDivide(odds, math.add(odds, 1));
}


function probabilityFromLogOdds(log_odds) {
    // noinspection JSUnresolvedFunction,JSUnresolvedVariable
    const odds = math.exp(log_odds);
    return probabilityFromOdds(odds);
}


// ============================================================================
// Model
// ============================================================================

function buildModel(n, debug = false) {

    // ------------------------------------------------------------------------
    // Define the size of our problem.
    // ------------------------------------------------------------------------
    const k = PREDICTOR_NAMES.length;  // number of predictors
    // n is a parameter, as above
    if (debug) {
        console.log("k:", k);
        console.log("n:", n);
    }

    // ------------------------------------------------------------------------
    // Set up X: define the presence of predictors.
    // Set up b, the vector of coefficients.
    // ------------------------------------------------------------------------
    // Note that Javascript has a funny idea of "const";
    // https://mariusschulz.com/blog/constant-variables-in-javascript-or-when-const-isnt-constant
    // noinspection JSUnresolvedFunction,JSUnresolvedVariable
    const X = math.zeros(n, k);  // presence/absence of predictors
    // noinspection JSUnresolvedFunction,JSUnresolvedVariable
    const b = math.zeros(k);  // coefficients
    for (let i = 0; i < k; ++i) {
        const predictor_name = PREDICTOR_NAMES[i];
        const p = PREDICTOR_PROBABILITIES[predictor_name];
        // X:
        for (let s = 0; s < n; ++s) {
            if (Math.random() < p) {  // Math.random() has range [0, 1)
                // noinspection JSUnresolvedFunction,JSUnresolvedVariable
                X.subset(math.index(s, i), 1);  // write 1 to position [s, i]
            }
        }
        // b:
        const coeff = PREDICTOR_DELTA_LOG_ODDS[predictor_name];
        // noinspection JSUnresolvedFunction,JSUnresolvedVariable
        b.subset(math.index(i), coeff);
    }

    // ------------------------------------------------------------------------
    // Create y_pred, the predicted values.
    // ------------------------------------------------------------------------
    // noinspection JSUnresolvedFunction,JSUnresolvedVariable
    const y_pred = math.multiply(X, b);

    // ------------------------------------------------------------------------
    // Create y, the actual binary variables.
    // ------------------------------------------------------------------------
    // noinspection JSUnresolvedFunction,JSUnresolvedVariable
    const y_error = math.zeros(n);
    for (let s = 0; s < n; ++s) {
        // noinspection JSUnresolvedFunction,JSUnresolvedVariable
        y_error.subset(math.index(s), randStandardNormal() * SD_LOG_ERROR);
    }
    // noinspection JSUnresolvedFunction,JSUnresolvedVariable
    const y_log_odds = math.add(y_pred, y_error);
    const y_probability = probabilityFromLogOdds(y_log_odds);
    // noinspection JSUnresolvedFunction,JSUnresolvedVariable
    const y = math.zeros(n);
    for (let s = 0; s < n; ++s) {
        // noinspection JSUnresolvedFunction,JSUnresolvedVariable
        const p = y_probability.subset(math.index(s));
        if (Math.random() < p) {
            // noinspection JSUnresolvedFunction,JSUnresolvedVariable
            y.subset(math.index(s), 1);
        }
    }

    if (debug) {
        console.log("X:", X);
        console.log("b:", b);
        console.log("y_pred:", y_pred);
        console.log("error:", y_error);
        console.log("y_log_odds:", y_log_odds);
        console.log("y_probability:", y_probability);
        console.log("y:", y);
    }

    // ------------------------------------------------------------------------
    // Count interesting demographics
    // ------------------------------------------------------------------------
    const idx_female = PREDICTOR_NAMES.indexOf(KEY_FEMALE);
    const idx_adult = PREDICTOR_NAMES.indexOf(KEY_ADULT);
    // Note that Javascript is rubbish at this. You can't use a variable as
    // a dictionary key for initialization.
    // Javascript is also rubbish at iterating over values of an array...
    let affected_by_age_gender = {};
    let unaffected_by_age_gender = {};
    for (let key_idx = 0; key_idx < AGE_GENDER_KEYS.length; ++key_idx) {
        const key = AGE_GENDER_KEYS[key_idx];
        affected_by_age_gender[key] = 0;
        unaffected_by_age_gender[key] = 0;
    }
    let affected_by_risk_factor = {};
    let unaffected_by_risk_factor = {};
    for (let key_idx = 0; key_idx < PREDICTOR_NAMES.length; ++key_idx) {
        const key = PREDICTOR_NAMES[key_idx];
        affected_by_risk_factor[key] = 0;
        unaffected_by_risk_factor[key] = 0;
    }
    for (let s = 0; s < n; ++s) {
        // noinspection JSUnresolvedFunction,JSUnresolvedVariable
        const female = X.subset(math.index(s, idx_female));
        // noinspection JSUnresolvedFunction,JSUnresolvedVariable
        const adult = X.subset(math.index(s, idx_adult));
        // noinspection JSUnresolvedFunction,JSUnresolvedVariable
        const affected = y.subset(math.index(s));
        const age_gender = female
            ? (adult ? KEY_WOMEN : KEY_GIRLS)
            : (adult ? KEY_MEN : KEY_BOYS);
        if (affected) {
            affected_by_age_gender[age_gender] += 1;
        } else {
            unaffected_by_age_gender[age_gender] += 1;
        }
        for (let j = 0; j < k; ++j) {
            const risk_factor_name = PREDICTOR_NAMES[j];
        // noinspection JSUnresolvedFunction,JSUnresolvedVariable
            const risk_factor_present = X.subset(math.index(s, j));
            if (risk_factor_present) {
                if (affected) {
                    affected_by_risk_factor[risk_factor_name] += 1;
                } else {
                    unaffected_by_risk_factor[risk_factor_name] += 1;
                }
            }
        }
    }
    // Summarizing
    let n_by_age_gender = {};
    for (let key in affected_by_age_gender) {
        n_by_age_gender[key] =
            affected_by_age_gender[key] + unaffected_by_age_gender[key];
    }
    let n_by_risk_factor = {};
    for (let key in affected_by_risk_factor) {
        n_by_risk_factor[key] =
            affected_by_risk_factor[key] + unaffected_by_risk_factor[key];
    }
    // noinspection JSUnresolvedFunction,JSUnresolvedVariable
    const total_affected = math.sum(y);
    const total_unaffected = n - total_affected;
    if (debug) {
        console.log("affected_by_age_gender:", affected_by_age_gender);
        console.log("unaffected_by_age_gender:", unaffected_by_age_gender);
        console.log("n_by_age_gender:", n_by_age_gender);
        console.log("affected_by_risk_factor:", affected_by_risk_factor);
        console.log("unaffected_by_risk_factor:", unaffected_by_risk_factor);
        console.log("n_by_risk_factor:", n_by_risk_factor);
        console.log("total_affected:", total_affected);
        console.log("total_unaffected:", total_unaffected);
    }

    // ------------------------------------------------------------------------
    // Unadjusted 95% confidence intervals
    // ------------------------------------------------------------------------
    let ci_data = {};
    for (let j = 0; j < k; ++j) {
        const key = PREDICTOR_NAMES[j];
        const affected_with_risk_factor = affected_by_risk_factor[key];
        const unaffected_with_risk_factor = unaffected_by_risk_factor[key];
        const affected_without_risk_factor = total_affected - affected_with_risk_factor;
        const unaffected_without_risk_factor = total_unaffected - unaffected_with_risk_factor;
        ci_data[key] = getRatio(
            affected_with_risk_factor,
            affected_without_risk_factor,
            unaffected_with_risk_factor,
            unaffected_without_risk_factor
        )
    }
    if (debug) {
        console.log("ci_data:", ci_data);
    }

    // ------------------------------------------------------------------------
    // Write counts back to document
    // ------------------------------------------------------------------------

    let gender_age_table_html = thead(tr([
        "Gender/Age",
        "Affected",
        "Unaffected",
        "Total"
    ], "th"));
    let gender_age_inner_html = "";
    for (let i = 0; i < AGE_GENDER_KEYS.length; ++i) {
        const key = AGE_GENDER_KEYS[i];
        const n_this_group = n_by_age_gender[key]
        gender_age_inner_html += tr([
            key,
            n_percent(affected_by_age_gender[key], n_this_group),
            n_percent(unaffected_by_age_gender[key], n_this_group),
            bold(n_this_group.toString())
        ])
    }
    gender_age_table_html += tbody(gender_age_inner_html);
    gender_age_table_html += tfoot(tr([
        bold("Total"),
        bold(n_percent(total_affected, n)),
        bold(n_percent(total_unaffected, n)),
        bold(n.toString())
    ]));
    document.getElementById(HTML_ID_AGE_GENDER_TABLE).innerHTML =
        gender_age_table_html;

    let risk_factor_table_html = thead(tr([
        "Risk factor",
        "Affected",
        "Unaffected",
        "Total",
        "Odds ratio",
    ], "th"));
    let risk_factor_inner_html = "";
    for (let i = 0; i < PREDICTOR_NAMES.length; ++i) {
        const key = PREDICTOR_NAMES[i];
        const odds_ratio = ci_data[key][KEY_ODDS_RATIO];
        const odds_ratio_text = isNaN(odds_ratio) ? "" : odds_ratio.toString();
        const n_this_group = n_by_risk_factor[key];
        risk_factor_inner_html += tr([
            key,
            n_percent(affected_by_risk_factor[key], n_this_group),
            n_percent(unaffected_by_risk_factor[key], n_this_group),
            bold(n_this_group.toString()),
            odds_ratio_text
        ])
    }
    risk_factor_table_html += tbody(risk_factor_inner_html);
    document.getElementById(HTML_ID_RISK_FACTOR_TABLE).innerHTML =
        risk_factor_table_html;

    plotOddsRatio(ci_data);
}


// ============================================================================
// Plotting
// ============================================================================

function plotOddsRatio(ci_data) {

    // Plot odds ratios with confidence intervals.

    // noinspection JSUnresolvedFunction,JSUnresolvedVariable
    Plotly.purge(HTML_ID_GRAPH);

    const one_line = {
        type: 'scatter',
        mode: 'lines',
        name: 'No effect',
        x: [1, 1],
        y: [0, 12],
        marker: {
            line: {width: 0}, 
            color: '#8FBBD9'
        }, 
    };

    let data = [one_line];
    let y_tickvals = [];
    let y_ticktext = [];

    for (let i = 1; i < PREDICTOR_NAMES.length; ++i) {  // skip the first, the intercept
        const y = i - 1;
        const key = PREDICTOR_NAMES[i];
        const group = ci_data[key];
        const odds_ratio = group[KEY_ODDS_RATIO];
        const ci_lower = group[KEY_CI_LOWER];
        const ci_upper = group[KEY_CI_UPPER];
        // Note that we have to specify the length of error bars, not their
        // actual position.
        const error_bar_plus = ci_upper - odds_ratio;
        const error_bar_minus = odds_ratio - ci_lower;
        // We add multiple traces, because that allows multiple colours.
        const trace = {
            type: 'scatter',
            mode: 'markers',
            name: key,
            x: [odds_ratio],
            y: [y],
            error_x: {
                array: [error_bar_plus],
                arrayminus: [error_bar_minus],
            },
        };
        // noinspection JSCheckFunctionSignatures
        data.push(trace);
        y_tickvals.push(y);
        y_ticktext.push(key);
    }

    const layout = {
        showlegend: false,
        title: {
            text: 'Risk factors'
        },
        xaxis: {
            // OR plots are best shown as logs:
            type: "log",
            // Fix the range so we can see the effects of changing n:
            range: [-2, 2],  // In log units.
            title: {
                text: 'Odds ratio (1 means “no effect”)'
            },
            tickvals: [
                0.01, 0.02, 0.05,
                0.1, 0.2, 0.5,
                1, 2, 5,
                10, 20, 50, 100
            ]
        },
        yaxis: {
            // Plot from top to bottom (to match table), not bottom to top:
            autorange: "reversed",
            tickmode: "array",
            tickvals: y_tickvals,
            ticktext: y_ticktext,
        },
        dragmode: false, 
        template: {
            layout: {
                xaxis: {
                    zerolinecolor: '#EBF0F8',
                },
                yaxis: {
                    zerolinecolor: '#EBF0F8',
                },
                colorway: [
                    '#636efa', '#EF553B', '#00cc96', '#ab63fa', '#19d3f3',
                    '#e763fa', '#fecb52', '#ffa15a', '#ff6692', '#b6e880'
                ],
                hovermode: 'closest',
            }, 
        }, 
    };
    // noinspection JSUnresolvedFunction,JSUnresolvedVariable
    Plotly.plot(HTML_ID_GRAPH, {
        data: data,
        layout: layout
    });
}
